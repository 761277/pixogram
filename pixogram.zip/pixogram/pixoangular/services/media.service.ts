import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Media } from 'src/model/media';
import { User } from 'src/model/user';

@Injectable({
  providedIn: 'root'
})
export class MediaService {

  baseUrl = 'http://localhost:8089';

  constructor(private http: HttpClient) { }

  getMedias(userId: number): Observable<Media[]> {
    return this.http.get<Media[]>(`${this.baseUrl}/media/${userId}`);
  }

  getFollowingsMedia(id: number): Observable<Media[]> {
    return this.http.get<Media[]>(`${this.baseUrl}/media/followings/${id}`);
  }

  postComments(comment:Comment):Observable<Comment>
  {
    return this.http.post<Comment>(`${this.baseUrl}/media/postcomment/`,comment);
  }
  getComments(userId:number,postId:number):Observable<Comment>{
    return this.http.get<Comment>(`${this.baseUrl}/media/getcomments/${userId}/${postId}`);
  }
}
