package com.social.pixogram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.pixogram.model.Newsfeed;
import com.social.pixogram.repository.NewsfeedRepo;
@Service
public class NewsfeedServiceImpl implements NewsfeedService{

	@Autowired
	NewsfeedRepo newsfeedRepo;
	@Override
	public void save(Newsfeed newsFeed) {
		newsfeedRepo.save(newsFeed);
		
	}
	@Override
	public List<Newsfeed> findAllByUserId(long userId) {
		// TODO Auto-generated method stub
		return newsfeedRepo.findAllByUserId(userId);
	}

}
